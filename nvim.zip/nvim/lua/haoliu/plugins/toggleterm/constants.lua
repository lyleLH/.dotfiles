local M = {}
-----------------------------------------------------------
-- Constants
-----------------------------------------------------------
M.term_ft = "toggleterm"
-- -30 is a magic number based on manual testing of what looks good
M.shading_amount = -30

return M
